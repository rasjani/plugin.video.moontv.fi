MoonTV.fi for XBMC
==================

### Summary

Watch series from [Moon TV](http://moontv.fi) within 
the [XBMC](http://xbmc.org) interface.

### Features

* Browse 10 latest episodes
* Browse all programs 


### Setup/Installation

TBD

### To Do

* Favourites support
* Search ? 

### Contact

Jani Mikkonen <jani.mikkonen@gmail.com>
FREENODE IRC: jani
rasjani on [http://forum.xbmc.org](http://forum.xbmc.org)

